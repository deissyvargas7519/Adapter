
package adapter.examples.productos;

public class SimpleProducto {

    private String name;
    private String client;

    public SimpleProducto(String name, String client) {
        this.name = name;
        this.client = client;
    }

    public String getName() {
        return name;
    }

    public String getClient() {
        return client;
    }
}