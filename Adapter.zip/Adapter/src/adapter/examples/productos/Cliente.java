package adapter.examples.productos;


public class Cliente{
    public static void main(String[] args) {
        Producto producto;
        producto = new AdapterProducto(new SimpleProducto("Computador HP", "Deissy Vargas"));
        System.out.println(producto.getNameAndClient());
    }
}