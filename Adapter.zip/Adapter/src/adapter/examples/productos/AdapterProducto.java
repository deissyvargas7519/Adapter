package adapter.examples.productos;

public class AdapterProducto implements Producto{

    private SimpleProducto producto;

    public AdapterProducto(SimpleProducto producto) {
        this.producto = producto;
    }

    @Override
    public String getNameAndClient(){
        return producto.getName() + " pertenece al cliente " + producto.getClient();
    }

}