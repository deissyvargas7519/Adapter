package adapter.examples.productos;

public interface Producto {
    public String getNameAndClient();
}